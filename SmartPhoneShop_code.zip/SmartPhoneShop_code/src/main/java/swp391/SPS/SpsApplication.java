package swp391.SPS;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpsApplication.class, args);
	}
}
