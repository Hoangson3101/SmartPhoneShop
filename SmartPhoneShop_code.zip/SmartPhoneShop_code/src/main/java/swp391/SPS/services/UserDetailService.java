package swp391.SPS.services;

import swp391.SPS.entities.UserDetail;

public interface UserDetailService {
    UserDetail getUserDetailByUserId(int userId);
}
