package swp391.SPS.services;

import swp391.SPS.entities.Role;

import java.util.List;

public interface RoleService {
    List<Role> findAll();
}
