package swp391.SPS.exceptions;

public class UserNotFoundException extends Throwable {
    public UserNotFoundException(String s) {
    }
}
