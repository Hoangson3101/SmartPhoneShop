package swp391.SPS.exceptions;

public class AccessDeniedException extends Throwable {
    public AccessDeniedException(String message) {
    }
}
