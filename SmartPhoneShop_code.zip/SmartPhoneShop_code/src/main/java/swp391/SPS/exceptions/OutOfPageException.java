package swp391.SPS.exceptions;

public class OutOfPageException extends Throwable {
    public OutOfPageException(String s) {
    }
}
