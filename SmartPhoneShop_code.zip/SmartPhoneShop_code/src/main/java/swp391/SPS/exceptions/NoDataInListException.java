package swp391.SPS.exceptions;

public class NoDataInListException extends Throwable {
    public NoDataInListException(String s) {
    }
}
