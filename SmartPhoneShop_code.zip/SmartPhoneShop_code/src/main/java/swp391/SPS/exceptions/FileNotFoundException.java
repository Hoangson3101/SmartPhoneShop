package swp391.SPS.exceptions;

public class FileNotFoundException extends Throwable {
    public FileNotFoundException(String message) {
    }
}
